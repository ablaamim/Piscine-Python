from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
    description='my package',
    author='ablaammim',
    author_email='ablaamim@student.1337.ma',
    url='https://github.com/ablaamim/Piscine-Python/tree/master/Module-00-starting/ex09/ft_package',
    packages=find_packages(),
    install_requires=[],
)
